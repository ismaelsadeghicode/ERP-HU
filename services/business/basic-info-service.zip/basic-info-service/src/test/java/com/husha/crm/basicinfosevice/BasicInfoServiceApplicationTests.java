package com.husha.crm.basicinfosevice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
