package com.husha.crm.basicinfosevice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicInfoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicInfoServiceApplication.class, args);
	}

}
